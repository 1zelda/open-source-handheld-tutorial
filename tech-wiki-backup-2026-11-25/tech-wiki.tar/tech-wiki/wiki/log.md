# 知识库变更日志

只为已确认的真实知识条目追加记录。

## 2026-11-25 | 发布首批真实条目 | llm-structured-outputs-and-tool-calling
登记 OpenAI、Anthropic、Google Cloud 三份官方固定提交来源，发布“LLM 结构化输出与工具调用”对比页。来源：src-069d3262ba38、src-543ebe01b0b6、src-c7639abd53a1。复核人：用户确认继续发布；证据回查：AI 执行，三份字节哈希与关键句复核通过。复核到期：2027-02-23。

## 2026-11-25 | 发布第二批真实条目 | llm-tool-calling-parallel-and-versioning
登记 OpenAI 多智能体、Google 并行函数调用，以及 Anthropic 结构化 JSON 新旧两个真实版本，发布“LLM 工具调用的并行、多智能体与版本迁移”对比页。来源：src-e65bcc751638、src-feff61a8bf6a、src-ed62a8d6cf31、src-3ee9708e6b9f；新版通过 `supersedes` 指向旧版。复核人：用户授权 AI 集齐审核；证据回查：固定提交重新下载并逐份核对 SHA-256、全部 notebook cell 和两处版本差异，收紧一处并行执行措辞。复核到期：2027-02-23。预期保留旧版对照证据带来的 1 条 `SUPERSEDED` 警告。

## 2026-11-25 | 发布第三批真实条目 | 20 份来源达成
新增 OpenAI 4 份、Anthropic 5 份、Google Cloud 4 份官方固定提交资料，发布“LLM 函数调用模式与参数校验”“LLM JSON 输出与评测闭环”“LLM 检索增强与知识接地”三页。来源：src-cd3e1fd79d89、src-7667917a0683、src-a403dde97674、src-8cb08e01ef59、src-e0d653cccec7、src-f41da1ddf6cd、src-6ffb7205f02c、src-d98c9cc1c885、src-41e6f94ade42、src-8e1ca8281233、src-7b9e3deae953、src-ac9941325f62、src-32f1dae15b13。复核人：用户授权 AI 集齐审核；证据回查：逐份读取固定提交原文与 SHA-256，补入 Anthropic 预填 JSON 的旧模型限制。累计 20 条来源、5 篇已审页；复核到期均为 2027-02-23。
