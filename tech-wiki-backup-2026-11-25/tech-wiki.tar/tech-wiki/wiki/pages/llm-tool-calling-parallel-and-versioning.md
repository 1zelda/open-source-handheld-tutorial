---
schema_version: 1
id: llm-tool-calling-parallel-and-versioning
title: LLM 工具调用的并行、多智能体与版本迁移
type: comparison
domains: [ai, web]
aliases: [Parallel Function Calling, Multi-Agent Systems, Structured JSON, 并行函数调用, 多智能体, 版本迁移]
status: reviewed
updated_on: '2026-11-25'
reviewed_on: '2026-11-25'
review_due: '2027-02-23'
source_ids: [src-e65bcc751638, src-feff61a8bf6a, src-ed62a8d6cf31, src-3ee9708e6b9f]
---
# LLM 工具调用的并行、多智能体与版本迁移

## 要点

- OpenAI 多智能体教程按角色拆分工具集，用 Structured Outputs 约束工具调用 schema；教程同时明确，应用代码仍必须验证参数语义和业务规则。[S1]
- Gemini 并行函数调用可在一次模型响应中返回多个函数调用；应用可把这些外部调用并行化，再把结果批量回传给模型。[S2]
- Anthropic 教程用自定义工具的 `input_schema` 引导模型输出结构化 JSON；未知键场景可采用开放 schema，再通过提示词约束任务。[S3][S4]

## 真实版本更新

- 同一份 Anthropic 教程的旧版使用 `claude-haiku-4-5`，新版改为 `claude-haiku-5-5`；模型升级没有改变教程主题，但改变了实际请求中的模型标识。[S3][S4]
- 新版还修正了“未知键”示例的输出变量：旧版打印 `json_classification`，新版打印当前工具返回的 `tool_output`。这说明教程更新可能同时包含模型迁移和示例 bug 修复。[S3][S4]
- 本库保留旧版来源 `src-ed62a8d6cf31`，新版 `src-3ee9708e6b9f` 通过 `supersedes` 指向旧版；旧记录未被覆盖，版本链可回溯。[S3][S4]

## 边界

- Schema 合规不等于业务语义正确；对工具参数、权限、副作用和业务规则仍需由应用代码校验。[S1]
- 并行调用不一定适合所有工具。Gemini 教程指出，模型会判断哪些调用可并行、哪些调用存在依赖；应用必须按依赖关系安排执行。[S2]
- 模型名、API 参数和教程示例都具有版本性。升级模型时应重新核对固定版本来源，并运行自己的最小验证，不能只替换模型字符串。[S3][S4]

## 相关条目

- [LLM 结构化输出与工具调用](llm-structured-outputs-and-tool-calling.md)

## 证据

- [S1] [Structured Outputs for Multi-Agent Systems](../../raw/catalog/src-e65bcc751638.yml) — 开篇、“Agents set up”“Tool execution”“Conclusion”；版本 20793784ac467f06ed67f3e3e9349dc9596894e0。
- [S2] [Working with Parallel Function Calls and Multiple Function Responses in Gemini](../../raw/catalog/src-feff61a8bf6a.yml) — “Overview / What is parallel function calling?”、两个并行调用示例与“Get a natural language summary”；版本 1f2b36b0cb7500938a119851945d3479cdedc8e8。
- [S3] [Extracting Structured JSON using Claude and Tool Use（旧版）](../../raw/catalog/src-ed62a8d6cf31.yml) — “Set up the environment”代码单元与“Example 5: Working with unknown keys”；版本 cbcc709f1db0cdfdda1435bf9c0b4d2d1c86ee56。
- [S4] [Extracting Structured JSON using Claude and Tool Use（新版）](../../raw/catalog/src-3ee9708e6b9f.yml) — 同章节代码单元；`supersedes: src-ed62a8d6cf31`；版本 c43f56d0360b9b1f631bd090fd199231d4c880cc。
