# M4 真实问答实测

日期：2026-11-25  
方法：按 [questions.md](questions.md) 锁定 10 道题、查询词与必需页面；仅把查询词传给 `search --limit 5`，未把答案键拼入查询。候选页确定后，再回查页内证据与固定提交来源。  
评测性质：用户授权 AI 担任本轮审阅者，属于本地自评，不是独立人工盲评。Q8 检索失败未被改查询或改口径掩盖。

## 总结

| 指标 | 结果 | 判定 |
|---|---|---|
| 候选召回 | Q1–Q7 通过，Q8 失败，7/8 | 通过（门槛 ≥7/8） |
| 必需页面同时召回 | Q2、Q6 的两个必需页面均进入前 5；其余题目的唯一必需页面均进入前 5 | 通过 |
| 答案实质正确 | Q1–Q8 均正确，8/8 | 通过 |
| 关键事实引用可定位 | Q1–Q8 均给出来源 ID、章节/cell 与版本，8/8 | 通过 |
| 不确定性 | Q9、Q10 均明确指出证据缺口 | 通过 |
| 结构 | `reindex --check` 通过；`lint` 0 错误、21 条可解释警告 | 通过 |

## 候选召回明细

候选列表只记页面 ID；完整命令输出保存在本轮临时缓存，结果写入本文件后清理。

| 题号 | 前 5 候选（实际顺序） | 必需页面命中 | 召回 |
|---|---|---|---|
| Q1 | `llm-structured-outputs-and-tool-calling`、`llm-function-calling-modes-and-validation`、`llm-tool-calling-parallel-and-versioning`、`llm-json-output-and-evaluation-loop`、`llm-retrieval-augmentation-and-grounding` | `llm-function-calling-modes-and-validation`（第 2） | 是 |
| Q2 | `llm-json-output-and-evaluation-loop`、`llm-function-calling-modes-and-validation`、`llm-retrieval-augmentation-and-grounding`、`llm-structured-outputs-and-tool-calling`、`llm-tool-calling-parallel-and-versioning` | JSON 评测页（第 1）、结构化输出页（第 4） | 是 |
| Q3 | `llm-retrieval-augmentation-and-grounding`、`llm-function-calling-modes-and-validation`、`llm-json-output-and-evaluation-loop` | RAG 页（第 1） | 是 |
| Q4 | `llm-json-output-and-evaluation-loop`、`llm-tool-calling-parallel-and-versioning`、`llm-structured-outputs-and-tool-calling`、`llm-function-calling-modes-and-validation`、`llm-retrieval-augmentation-and-grounding` | JSON 评测页（第 1） | 是 |
| Q5 | `llm-tool-calling-parallel-and-versioning`、`llm-structured-outputs-and-tool-calling` | 并行与版本页（第 1） | 是 |
| Q6 | `llm-function-calling-modes-and-validation`、`llm-structured-outputs-and-tool-calling`、`llm-tool-calling-parallel-and-versioning`、`llm-json-output-and-evaluation-loop`、`llm-retrieval-augmentation-and-grounding` | 函数模式页（第 1）、并行与版本页（第 3） | 是 |
| Q7 | `llm-retrieval-augmentation-and-grounding`、`llm-function-calling-modes-and-validation`、`llm-json-output-and-evaluation-loop` | RAG 页（第 1） | 是 |
| Q8 | `no results` | 并行与版本页未召回 | 否 |

Q8 暴露的是英文长句精确召回失败，不是资料缺失。当前门槛允许 1 题失败，因此本轮候选召回通过；后续若同一失败连续出现，再按计划评估别名或检索增强，不在本轮临时改题。

## 答案与证据

### Q1｜工具调用闭环

**答案：** 模型根据工具声明生成函数名和参数，但不会执行外部函数。应用先检查调用，再提取参数并执行，随后把工具结果追加到消息中再次请求模型，才能得到基于工具结果的最终回答。

**证据：** `src-cd3e1fd79d89`，How to call functions with chat models，开篇与 `cell-35` 四步说明；版本 `20793784ac467f06ed67f3e3e9349dc9596894e0`。  
**判定：** 实质正确，引用可定位。

### Q2｜Schema 与业务正确性

**答案：** JSON Schema 只能约束结构和类型，不能证明参数语义、权限或业务规则正确。评测应把“可解析/schema 通过率”与“内容准确率”分开；前者可用 `jsonschema` 检查，后者应与参考答案做内容比较，而不是只看 JSON 字符串是否完全一致。

**证据：** `src-e65bcc751638` Conclusion 明确要求应用验证参数语义与业务规则；`src-41e6f94ade42` 的 `valid_schema` 与 `accuracy` 自定义指标及 `exact_match` 局限；`src-d98c9cc1c885` 的代码/人工/模型 grader。版本分别为 `20793784...` 与 `1f2b36b0...`、`c43f56d0...`。  
**判定：** 实质正确，引用可定位。

### Q3｜RAG 分层评测

**答案：** 必须分开评测，因为错误可能来自“没有检索到相关文档”，也可能来自“文档正确但模型推理错误”。常用检索指标包括 Precision、Recall、F1 和 MRR；最终答案质量另行评测。

**证据：** `src-7b9e3deae953` 的 “Eval Setup” 与 “Metric Definitions”；`src-8e1ca8281233` 的 “Troubleshooting wrong answers” 建议检查实际喂给模型的文本。版本分别为 `c43f56d0...`、`20793784...`。  
**判定：** 实质正确，引用可定位。

### Q4｜Claude JSON Mode 预填兼容性

**答案：** 不能直接用于 Claude Haiku 5.5。该固定版本写明，预填 `{` 只被旧版 Claude Haiku 4.5 接受；当前模型（包括 Claude Haiku 5.5）会返回 400。

**证据：** `src-6ffb7205f02c`，Prompting Claude for JSON Mode，模型注释与预填示例；版本 `c43f56d0360b9b1f631bd090fd199231d4c880cc`。  
**判定：** 实质正确，引用可定位。

### Q5｜Anthropic 真实续版

**答案：** 旧版使用 `claude-haiku-4-5`，新版改为 `claude-haiku-5-5`；“未知键”示例还把错误的 `json_classification` 输出改为当前工具结果 `tool_output`。新版来源 `src-3ee9708e6b9f` 通过 `supersedes` 指向 `src-ed62a8d6cf31`，旧记录仍保留。

**证据：** 两份来源的 `cell-3` 与 “Example 5” `cell-12`–`cell-13`；旧版 `cbcc709f1db0cdfdda1435bf9c0b4d2d1c86ee56`，新版 `c43f56d0360b9b1f631bd090fd199231d4c880cc`。  
**判定：** 实质正确，引用可定位。

### Q6｜`required` 与 `ANY` 的综合边界

**答案：** OpenAI `required` 让每次请求都产生工具调用，Gemini `ANY` 强制模型从允许的函数集合中调用。二者提高的是控制流确定性；它们不保证参数语义、权限或业务规则正确，也不能绕过应用校验。

**证据：** `src-7667917a0683` 开篇与 `cell-4`；`src-8cb08e01ef59` 的 `cell-21`、`ANY` 示例；`src-a403dde97674` 的 Pydantic 校验 `cell-5`、`cell-11`。版本分别为 `20793784...`、`1f2b36b0...`、`c43f56d0...`。  
**判定：** 实质正确，引用可定位。

### Q7｜三种外部知识路线

**答案：** OpenAI Search-Ask 是嵌入检索相关文本后放入提示词；Anthropic Contextual Retrieval 在嵌入前为每个分块生成文档语境说明，并可结合 BM25 与重排；Gemini Grounding 通过 `GoogleSearch` 或 `VertexAISearch` 检索公开网页或自定义文档，并在响应中提供 grounding metadata/引用。

**证据：** `src-8e1ca8281233` 的 “Search-Ask” 与 “Ask”；`src-ac9941325f62` 的 “Contextual Embeddings”“Contextual BM25”“Reranking”；`src-32f1dae15b13` 的 Google Search 与自定义文档示例。版本分别为 `20793784...`、`c43f56d0...`、`1f2b36b0...`。  
**判定：** 实质正确，引用可定位。

### Q8｜精确出处

**答案：** 这句话出自 OpenAI 的 Structured Outputs for Multi-Agent Systems，位于 Conclusion。来源 ID 为 `src-e65bcc751638`，版本为 `20793784ac467f06ed67f3e3e9349dc9596894e0`。

**证据：** 该 notebook 的 `cell-18` Conclusion 原文：“Structured Outputs ensures that tool calls follow the specified schema. Application code must still validate argument semantics and business rules.”  
**判定：** 答案与引用正确；英文原句检索召回失败，计入 7/8。

### Q9｜Mistral 证据不足

**答案：** 无法证明。本库没有 Mistral 官方函数调用文档或对应版本来源，不能用 OpenAI、Google 或 Anthropic 的行为外推其默认并行设置和模型支持列表。

**证据边界：** 搜索返回的其他供应商页面与 Mistral 无关，不构成证据。  
**判定：** 正确指出证据缺口。

### Q10｜Claude 全地区/全端点证据不足

**答案：** 无法证明。现有来源只覆盖固定教程中的能力说明和预填限制，没有提供所有地区、API 端点、账号类型与产品形态的支持矩阵。

**证据边界：** `src-6ffb7205f02c` 只能证明该固定版本中的预填限制与结构化输出提示，不能扩展为全域承诺。  
**判定：** 正确指出适用版本与覆盖范围不足。

## 复现命令

```text
./.venv/Scripts/python.exe scripts/kb.py search "<questions.md 中的查询词>" --as-of 2026-11-25 --limit 5
./.venv/Scripts/python.exe scripts/kb.py reindex --as-of 2026-11-25 --check
./.venv/Scripts/python.exe scripts/kb.py lint --as-of 2026-11-25
./.venv/Scripts/python.exe -m unittest discover -s tests -v
```

## 本轮未验证

- 独立人工盲评尚未进行。
- Obsidian 客户端显示尚未实测。
- 固定链接没有离线快照，Q1–Q10 的“可定位”指章节/cell 与固定提交链接可定位，不代表断网后可复核。
- 备份恢复将在本文件之后单独执行并记录。
