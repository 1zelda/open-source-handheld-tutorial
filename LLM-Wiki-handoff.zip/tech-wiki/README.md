# 个人技术 LLM Wiki

本地、模型无关的知识库骨架。资料登记、检索、索引与质检走 CLI；AI 或人工负责写作与事实核对。当前仓库不含真实资料。Obsidian 用「打开文件夹作为仓库」选本目录，再打开 `wiki/index.md`；不必安装任何插件。

## Windows 安装和验证

在 `tech-wiki/` 内运行（Git Bash 用 `./.venv/Scripts/python.exe` 替换下列 `python`，或先激活环境；首次另用系统 Python 创建环境）：

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

安装后，使用该环境的 Python。示例日期可用当天日期替换，搜索未传日期则按本机当日计算。

```text
python scripts/kb.py --help
python scripts/kb.py reindex --as-of 2026-11-25
python scripts/kb.py reindex --as-of 2026-11-25 --check
python scripts/kb.py search "客户端预测" --domain games
python scripts/kb.py lint --as-of 2026-11-25
python -m unittest discover -s tests -v
```

## 首批资料操作

1. 先由用户确认资料公开、保存范围和是否允许向特定模型发送指定内容。放入 `inbox/` 的是授权文件与元数据；仅链接的来源不用保存正文。CLI 不主动联网，不执行原文。
2. 新建 `inbox/example.yml`，把虚构 URL、标题和日期换成真实值：

```yaml
title: 公开技术资料标题
url: https://example.invalid/docs/demo
publisher: 资料发布方
kind: official-doc
published_on: null
captured_on: '2026-11-25'
version: null
access: public
```

3. 链接用 `python scripts/kb.py register --meta inbox/example.yml`；允许保存文件时加 `--file inbox/example.md`。同身份重复登记不会覆盖来源或快照。不同版本需要新记录，确认同来源的续版可传 `supersedes`。
4. 将来源 ID 交给 AI，要求先查同义词或同主题条目、提出差异、引用原文定位。用户确认后再写正式条目并更新日志。字段与证据格式见外部《实施说明书》。重建索引、运行质检；仅摘录链接无法证明内容已核验。

## 备份与故障处理

- Git 历史只覆盖跟踪文件，不覆盖 `raw/blobs/`。经用户确认后分别备份规则、代码、Git 跟踪内容和原文；在新的受控目录恢复并跑 `lint`。不向远程推送。不把 `.venv/` 当作可迁移依赖，按锁定版本重新创建。
- 空库克隆或恢复后可手工创建 `inbox/`、`raw/catalog/`、`raw/blobs/`、`wiki/pages/` 等空目录。缺快照或 SHA-256 不符时从经核对的备份恢复原始字节，不改哈希、不手工伪造来源。
- `reindex --check` 报差异时先核对日期及改动；合法则重建。`lint` 警告需人工核实，不能用重建来掩盖。已提交的 Wiki 修订如需撤回，经确认可 `git revert`；原文不要删除。
- 第一版搜索是可预测的短语/关键词匹配；不自动回答、不做语义搜索。真实资料试运行、问答验收和备份恢复见《实施计划书》。
