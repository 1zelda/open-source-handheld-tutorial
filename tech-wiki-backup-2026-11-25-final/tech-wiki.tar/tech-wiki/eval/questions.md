# M4 真实问题题库

日期：2026-11-25  
出题与判定：用户授权 AI 担任本轮审阅者；这是本地自评，不冒充独立人工评测。  
规则：先锁定问题、查询词、必需页面和判定依据，再运行 `search`；检索阶段只使用“查询词”，不把答案键拼入查询。候选召回只统计 Q1–Q8，Q9–Q10 单独检查不确定性。

| 编号 | 题型 | 问题 | 检索查询词 | 必需页面 | 判定依据 |
|---|---|---|---|---|---|
| Q1 | 概念 | 模型返回工具调用后，谁负责执行函数？正确闭环包含哪些步骤？ | 工具调用 执行 四步 回传 | `llm-function-calling-modes-and-validation` | 必须说明模型只生成函数名/参数，应用检查并执行，结果回传后再次请求模型；不能声称模型已执行工具。 |
| Q2 | 概念 | 为什么 JSON schema 合规不等于业务正确？结构化输出应如何分别评测？ | schema 业务 内容 准确率 评测 | `llm-json-output-and-evaluation-loop`、`llm-structured-outputs-and-tool-calling` | 必须区分格式/schema 与业务语义，并至少给出 schema/可解析率和内容准确率两类指标。 |
| Q3 | 概念 | RAG 为什么要分别评测检索与端到端系统？常用检索指标有哪些？ | RAG 检索 端到端 Precision Recall MRR | `llm-retrieval-augmentation-and-grounding` | 必须说明检索失败与推理失败要分开定位，并正确提到 Precision、Recall、F1、MRR 中至少三项。 |
| Q4 | 版本/时效 | Anthropic JSON Mode 教程里的预填 `{` 能直接用于 Claude Haiku 5.5 吗？ | Claude Haiku 5.5 预填 JSON 400 | `llm-json-output-and-evaluation-loop` | 必须回答不能；固定版本写明仅旧版 Haiku 4.5 接受，当前模型包括 Haiku 5.5 返回 400。 |
| Q5 | 版本/时效 | Anthropic 结构化 JSON 教程从旧版到新版有哪些真实变化？旧来源是否被覆盖？ | claude-haiku-4-5 claude-haiku-5-5 supersedes | `llm-tool-calling-parallel-and-versioning` | 必须列出模型名变化与 `json_classification`→`tool_output` 修复；新版 `supersedes` 旧版，旧记录保留。 |
| Q6 | 跨源综合 | OpenAI `required` 与 Gemini `ANY` 都能强制工具调用，它们的作用和共同边界是什么？ | required ANY 强制 工具调用 校验 | `llm-function-calling-modes-and-validation`、`llm-tool-calling-parallel-and-versioning` | 必须说明二者增强控制流确定性，但不保证参数语义、权限或业务正确；应用仍需校验。第二页用于交叉核对并行调用边界。 |
| Q7 | 跨源综合 | 比较 OpenAI Search-Ask、Anthropic Contextual Retrieval、Gemini Grounding 三种外部知识路线。 | Search Ask Contextual Retrieval Grounding | `llm-retrieval-augmentation-and-grounding` | 必须分别说明嵌入检索后放入提示词、为分块添加上下文再嵌入、调用搜索/自定义库并返回 grounding metadata；不能混为同一机制。 |
| Q8 | 精确出处 | “Application code must still validate argument semantics and business rules” 出自哪份来源、哪个章节、哪个版本？ | Application code validate argument semantics business rules | `llm-tool-calling-parallel-and-versioning` | 必须定位 OpenAI `Structured Outputs for Multi-Agent Systems` 的 Conclusion，版本 `20793784ac467f06ed67f3e3e9349dc9596894e0`，来源 ID `src-e65bcc751638`。 |
| Q9 | 证据不足 | 本库能否证明 Mistral 当前版本的函数调用默认是否并行，以及完整模型支持列表？ | Mistral parallel_tool_calls 模型 支持 | 无 | 必须明确本库未收录 Mistral 官方来源，不能证明；不得用 OpenAI/Google/Anthropic 行为外推。 |
| Q10 | 证据不足 | 本库能否证明 Claude Haiku 5.5 在所有地区和所有 API 端点都支持结构化输出？ | Claude Haiku 5.5 所有地区 API 端点 结构化输出 | 无 | 必须指出现有来源只说明固定教程中的能力与预填限制，没有覆盖所有地区、端点与账号类型；结论应为证据不足。 |

## 通过门槛

- Q1–Q8 前 5 候选召回至少 7/8；标记为“必需”的页面必须全部进入前 5。
- Q1–Q8 至少 7/8 实质正确，关键事实引用可定位率 100%。
- Q9、Q10 都必须明确证据缺口，不自信补齐。
- 最终结果写入 `qa-results.md`，失败项不得通过改口径隐藏。
