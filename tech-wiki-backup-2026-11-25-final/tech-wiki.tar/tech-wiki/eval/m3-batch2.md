# M3 第二批：真实版本更新验证

日期：2026-11-25  
状态：4 条来源已登记，候选页已按用户授权完成原文复核并转 `reviewed`；正式日志已追加，未提交 Git。  
主题：LLM 工具调用的并行、多智能体与版本迁移。

## 来源登记

| 来源 ID | 发布方与标题 | 版本 | 材料形式 | 本次抓取字节 SHA-256 |
|---|---|---|---|---|
| `src-e65bcc751638` | OpenAI — [Structured Outputs for Multi-Agent Systems](https://github.com/openai/openai-cookbook/blob/20793784ac467f06ed67f3e3e9349dc9596894e0/examples/Structured_outputs_multi_agent.ipynb) | `20793784ac467f06ed67f3e3e9349dc9596894e0` | `link_only` | `9c6bac7c2613bb60da1acda34d947ea946d2415c2e3cf4465fd1e693fcaeac0a` |
| `src-feff61a8bf6a` | Google Cloud — [Working with Parallel Function Calls and Multiple Function Responses in Gemini](https://github.com/GoogleCloudPlatform/generative-ai/blob/1f2b36b0cb7500938a119851945d3479cdedc8e8/gemini/function-calling/parallel_function_calling.ipynb) | `1f2b36b0cb7500938a119851945d3479cdedc8e8` | `link_only` | `def78c1ab446688dc622947a744fe6e6a591a517d88fa1f6c75926ee0aa0b801` |
| `src-ed62a8d6cf31` | Anthropic — [Extracting Structured JSON using Claude and Tool Use（旧版）](https://github.com/anthropics/anthropic-cookbook/blob/cbcc709f1db0cdfdda1435bf9c0b4d2d1c86ee56/tool_use/extracting_structured_json.ipynb) | `cbcc709f1db0cdfdda1435bf9c0b4d2d1c86ee56` | `link_only` | `ba6939f366f89c2290555fe206cd6e51b5fdca7c88db03364479c06e34a94fcf` |
| `src-3ee9708e6b9f` | Anthropic — [Extracting Structured JSON using Claude and Tool Use（新版）](https://github.com/anthropics/anthropic-cookbook/blob/c43f56d0360b9b1f631bd090fd199231d4c880cc/tool_use/extracting_structured_json.ipynb) | `c43f56d0360b9b1f631bd090fd199231d4c880cc` | `link_only` | `2fca856390f4c6117a3135093048152d81c7e3a5a86614dee5eac1dc4589c872` |

四份来源均来自第一批已核对许可证的同一批官方仓库，继续使用固定提交链接，不把 notebook 与许可通知分离保存。

## 真实续版链

`src-3ee9708e6b9f` 的 `supersedes` 指向 `src-ed62a8d6cf31`，两者共享同一 `origin_key`。旧版仍保留原版本、URL 和空 `supersedes`，没有被覆盖。

实际正文差异只有两个代码单元：

1. `MODEL_NAME` 从 `claude-haiku-4-5` 改为 `claude-haiku-5-5`。
2. “Example 5: Working with unknown keys” 中，输出从错误的 `json_classification` 改为当前工具结果 `tool_output`。

这同时验证了真实模型迁移、示例 bug 修复、新版登记与旧版保留。

## 2026-11-25 原文审核

授权与范围：用户要求“集齐审核然后继续下一步”；本次只复核这 4 份固定提交 notebook，不执行其中的代码。审核人记为用户授权的 AI 复核，待用户随时抽查。

方法：按固定提交重新下载 4 份 notebook，SHA-256 与登记记录逐份一致；通读全部 cell，重点核对下列定位：

| 来源 | 回查定位 | 核对结论 |
|---|---|---|
| `src-e65bcc751638` | 开篇 `cell-0`、“Agents set up” `cell-4`–`cell-7`、“Tool execution” `cell-8`–`cell-15`、“Conclusion” `cell-18` | 角色工具集、`strict: true`、schema 约束和“应用代码仍须验证参数语义与业务规则”均与原文一致。 |
| `src-feff61a8bf6a` | “Overview / What is parallel function calling?” `cell-3`、同函数示例 `cell-15`–`cell-27`、多函数示例 `cell-28`–`cell-40` | 一次响应返回多个调用、批量回传结果、由模型判断依赖关系均与原文一致。示例代码本身串行循环，本页只表述应用“可并行化”，未声称 notebook 已实现并发。 |
| `src-ed62a8d6cf31` | “Set up the environment” `cell-3`、“Example 5” `cell-12`–`cell-13` | 旧模型名、开放 `input_schema`、提示词约束以及误打印 `json_classification` 均与原文一致。 |
| `src-3ee9708e6b9f` | 同章节 `cell-3`、`cell-12`–`cell-13` | 新模型名和改打印 `tool_output` 均与原文一致；新版续版指针正确。 |

审核结论：未发现需要撤回的事实性结论。将 Gemini 要点的措辞从“应用可并行执行”收紧为“应用可把这些外部调用并行化”，避免误读为 notebook 已实现并发；将边界中的“顺序、幂等和失败”收敛为原文明确支持的“按依赖关系安排执行”。

发布决定：2026-11-25 转 `reviewed`，`review_due` 为 `2027-02-23`。旧来源仍作为版本对照证据保留，因此转正后预期出现 1 条 `SUPERSEDED` 警告；该警告表示旧版已被新版接替，不表示引用无效。`LINK_ONLY` 仍为有意的固定链接保存策略。

## 候选条目

[LLM 工具调用的并行、多智能体与版本迁移](../wiki/pages/llm-tool-calling-parallel-and-versioning.md)，状态 `reviewed`，领域 `ai` 与 `web`。该页链接到首批已审条目，首批条目的 `ORPHAN_PAGE` 警告已由真实内容页反向链接消除。

## 实测记录

| 操作 | 实际结果 |
|---|---|
| 首次登记 4 条来源 | 创建 `src-e65bcc751638`、`src-feff61a8bf6a`、`src-ed62a8d6cf31`、`src-3ee9708e6b9f`，退出 0 |
| 再次登记同 4 条来源 | 全部返回 `duplicate` 与相同 ID，退出 0 |
| 读取新旧 Anthropic 目录记录 | 新版 `supersedes: src-ed62a8d6cf31`；旧版 `supersedes: null`，版本仍为 `cbcc709...` |
| `reindex --as-of 2026-11-25 --check` | `index OK`，退出 0；草稿未进入正式索引 |
| `lint --as-of 2026-11-25` | `0 error(s), 7 warning(s)`；均为 `LINK_ONLY`，退出 0 |
| `search "并行函数调用" --as-of 2026-11-25` | `no results`，退出 0；草稿默认不返回 |
| `search "LLM 结构化输出与工具调用" --as-of 2026-11-25` | 首批已审条目正常返回，退出 0 |
| `python -m unittest discover -s tests -v` | 7/7 通过，退出 0 |
| 转正后 `reindex --as-of 2026-11-25 --check` | `index OK`，2 篇已审页进入索引，退出 0 |
| 转正后 `lint --as-of 2026-11-25` | `0 error(s), 8 warning(s)`：7 条 `LINK_ONLY`、1 条预期 `SUPERSEDED`，退出 0 |
| 转正后 `search "并行函数调用" --as-of 2026-11-25` | 返回本页，状态 `reviewed`，退出 0 |

## 审核清单

- [x] 核对 OpenAI 多智能体与 Google 并行函数调用的归纳是否准确。
- [x] 核对 Anthropic 两个真实版本的差异，以及“schema 合规不等于业务语义正确”的边界。
- [x] 确认转 `reviewed`，填写复核日期；保留旧版证据并接受 1 条 `SUPERSEDED` 警告。

## 当前规模与边界

累计登记 7 条真实来源记录，其中 6 个不同来源身份、1 组真实续版；正式已审条目 2 篇。距离 M3 的 20–30 份来源目标仍差 13–23 份记录。Obsidian 客户端、10 道真实问答和备份恢复仍未执行。
