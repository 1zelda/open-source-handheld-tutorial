# M3 首批真实资料试运行

日期：2026-11-25  
状态：首批已完成发布；已转 `reviewed`、已追加正式变更日志，未提交 Git。  
主题：AI / LLM 工程 — 结构化输出与工具调用。  
授权：用户选择“联网筛选并生成草稿（推荐）”，允许当前 AI 读取公开资料并生成待审草稿。

## 来源登记

三份来源均为供应商官方 GitHub 教程，URL 已固定到具体提交，避免引用随 `main` 漂移。`published_on` 留空；提交日期只作为版本依据，不冒充首次发布日期。

| 来源 ID | 发布方与标题 | 版本 | 材料形式 | 本次抓取字节 SHA-256 |
|---|---|---|---|---|
| `src-069d3262ba38` | OpenAI — [Introduction to Structured Outputs](https://github.com/openai/openai-cookbook/blob/20793784ac467f06ed67f3e3e9349dc9596894e0/examples/Structured_Outputs_Intro.ipynb) | `20793784ac467f06ed67f3e3e9349dc9596894e0` | `link_only` | `05731b657039904eec7d55c5a69532a6227fe8b9747a54a19934d993e6d50dde` |
| `src-543ebe01b0b6` | Anthropic — [Tool choice](https://github.com/anthropics/anthropic-cookbook/blob/c43f56d0360b9b1f631bd090fd199231d4c880cc/tool_use/tool_choice.ipynb) | `c43f56d0360b9b1f631bd090fd199231d4c880cc` | `link_only` | `b7b66f81a0054d67915b49e883021215547ec347c649bb6077ff9a21c6a2fef2` |
| `src-c7639abd53a1` | Google Cloud — [Intro to Function Calling with the Gemini API & Python SDK](https://github.com/GoogleCloudPlatform/generative-ai/blob/d86c5cbb6d2401960509e1a15827afb1bb9a438a/gemini/function-calling/intro_function_calling.ipynb) | `d86c5cbb6d2401960509e1a15827afb1bb9a438a` | `link_only` | `262b14c8fe71dbbd951814941795c4d4bc836a09430aeea67eed662c4e4a8e68` |

许可证正文已核对：OpenAI 与 Anthropic 仓库为 MIT，Google 仓库为 Apache-2.0。本轮为避免 notebook 快照与许可通知分离，先登记固定链接；因此 `lint` 会保留 `LINK_ONLY` 警告，这是已知边界，不是静默降级。

## 候选条目

[LLM 结构化输出与工具调用](../wiki/pages/llm-structured-outputs-and-tool-calling.md)，状态 `reviewed`，领域 `ai` 与 `web`，审阅日 2026-11-25，复核到期 2027-02-23。重要结论均带 `[S1]`–`[S3]`，证据区写明来源 ID、章节与版本。

## 实测记录

| 操作 | 实际结果 |
|---|---|
| 首次 `register` 三份来源 | 分别创建 `src-069d3262ba38`、`src-543ebe01b0b6`、`src-c7639abd53a1`，退出 0 |
| 再次 `register` 同三份来源 | 分别返回 `duplicate` 与相同 ID，退出 0；未覆盖来源 |
| 发布前证据回查 | 重新通过 GitHub API 读取三份固定提交，SHA-256 与首次抓取一致；OpenAI、Anthropic、Google 关键证据句断言全部通过 |
| `reindex --as-of 2026-11-25` | `indexed 1 page(s); updated 3 file(s)`，退出 0；总索引、AI 与 Web 入口均已更新 |
| `reindex --as-of 2026-11-25 --check` | `index OK`，退出 0 |
| `lint --as-of 2026-11-25` | `0 error(s), 4 warning(s)`；三条 `LINK_ONLY` 与一条 `ORPHAN_PAGE`，退出 0 |
| 中文标题、英文别名、模型版本检索 | 均返回 `llm-structured-outputs-and-tool-calling`，状态 `reviewed`，退出 0 |
| `python -m unittest discover -s tests -v` | 7/7 通过，退出 0 |

## 审阅与发布

- [x] AI 重新读取三份固定提交，字节哈希与首次抓取一致，关键证据句断言通过。
- [x] 用户确认继续发布；条目转为 `reviewed`，审阅日 2026-11-25，复核到期 2027-02-23。
- [x] 已追加 `wiki/log.md`，重建总索引与 AI、Web 领域入口，并复跑质检和单测。
- [ ] Git 提交仍需单独授权；当前工作树保留未提交状态。

## 警告处置

| 警告 | 责任人 | 下次处理时间 | 处理方向 |
|---|---|---|---|
| `LINK_ONLY` × 3 | 用户 | 2027-02-23 | 复核前决定保留固定链接，或准备保留完整许可通知的本地快照包 |
| `ORPHAN_PAGE` × 1 | 用户 | 2027-02-23 | 下一篇同主题条目发布时增加双向链接；当前不造无来源页面消警 |

## 尚未完成

Obsidian 客户端显示、10 道真实问答、备份恢复，以及 M3 的 20–30 份来源目标。真实“同主题增量更新”和“旧版本不覆盖”尚未用真实续版验证；现有合成测试已覆盖对应机制，但不能冒充真实续版验收。
