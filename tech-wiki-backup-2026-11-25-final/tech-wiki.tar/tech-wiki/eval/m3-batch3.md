# M3 第三批：扩到 20 份真实来源

日期：2026-11-25  
授权：用户要求“集齐审核然后继续下一步”；本批沿用已核对许可证的 OpenAI Cookbook（MIT）、Anthropic Cookbook（MIT）与 Google Generative AI（Apache-2.0）官方仓库。  
结果：新增 13 条来源，累计 20 条来源记录、19 个不同来源身份（含 1 组真实续版）；新增 3 篇已审页，累计 5 篇已审页。未提交 Git。

## 来源登记

| 来源 ID | 发布方与标题 | 版本 | 本次抓取字节 SHA-256 |
|---|---|---|---|
| `src-cd3e1fd79d89` | OpenAI — How to call functions with chat models | `20793784ac467f06ed67f3e3e9349dc9596894e0` | `9e6946d759a3e03159236a5ad4544d89d0d77f90d6b94e34f896ed18275da459` |
| `src-7667917a0683` | OpenAI — Using Tool Required for Customer Service | `20793784ac467f06ed67f3e3e9349dc9596894e0` | `196893a63ca70b3d26db24b70c70f684f98de78782db55b53449e8631e6eac54` |
| `src-a403dde97674` | Anthropic — Note-Saving Tool with Pydantic and Anthropic Tool Use | `c43f56d0360b9b1f631bd090fd199231d4c880cc` | `35e0ea9b6be492f1ae38ad6575cf9bdcc87d6ef4b7f8f08f1cdb789cbb73f668` |
| `src-8cb08e01ef59` | Google Cloud — Forced Function Calling with Tool Configurations in Gemini | `1f2b36b0cb7500938a119851945d3479cdedc8e8` | `16e0a8c4aba5700972fc036efde0a88d358a2235813eebf8fb9386ca1305b76d` |
| `src-e0d653cccec7` | OpenAI — Getting Started with OpenAI Evals | `20793784ac467f06ed67f3e3e9349dc9596894e0` | `147a35843b750634c65493bf451758afe76c48ad95032435019a17c7720aeca4` |
| `src-f41da1ddf6cd` | OpenAI — Building resilient prompts using an evaluation flywheel | `20793784ac467f06ed67f3e3e9349dc9596894e0` | `4754f5f6c93b5fdb9519f6e68ea45f77d2695242712482e21b4de2ba3657715e` |
| `src-6ffb7205f02c` | Anthropic — Prompting Claude for JSON Mode | `c43f56d0360b9b1f631bd090fd199231d4c880cc` | `05c7a7be1fdcf5de7f85dd619240dae7971ef141e861305c4c20897cf3ab083b` |
| `src-d98c9cc1c885` | Anthropic — Building Evals | `c43f56d0360b9b1f631bd090fd199231d4c880cc` | `55404602407a112a1eaacf0abc527d30a009fd89d7b3c410add0ec7a34c6794e` |
| `src-41e6f94ade42` | Google Cloud — Evaluate Gemini Structured Output | `1f2b36b0cb7500938a119851945d3479cdedc8e8` | `f23236c402099dc98ffe248e5a5e313cc136fc4e99d3b027a9c4f19b718dcec6` |
| `src-8e1ca8281233` | OpenAI — Question answering using embeddings-based search | `20793784ac467f06ed67f3e3e9349dc9596894e0` | `272ac1e316ba0419e9c12d6bb83aab9c1ddcb882cc6a1051787cd234a9a03482` |
| `src-7b9e3deae953` | Anthropic — Retrieval Augmented Generation | `c43f56d0360b9b1f631bd090fd199231d4c880cc` | `b9b0be20263142b33f649fb4ea11abe0d9a624947267e6d809a79a68b060d0e6` |
| `src-ac9941325f62` | Anthropic — Enhancing RAG with Contextual Retrieval | `c43f56d0360b9b1f631bd090fd199231d4c880cc` | `1ef3cc0ce6439dba5e8a30c8de20bf19e81e1d5bacae95df28be61b16932f02e` |
| `src-32f1dae15b13` | Google Cloud — Intro to Grounding with Gemini | `1f2b36b0cb7500938a119851945d3479cdedc8e8` | `e421d4d5b007ac94b08c80138c05d5164d70f4a9b9375dcae97831111c50cc81` |

全部使用固定提交链接与 `link_only`，不执行 notebook 代码，不保存正文快照，避免把内容与仓库许可通知分离。

## 原文审核定位

| 条目 | 来源 | 核对重点 |
|---|---|---|
| [LLM 函数调用模式与参数校验](../wiki/pages/llm-function-calling-modes-and-validation.md) | `src-cd3e1fd79d89`、`src-7667917a0683`、`src-a403dde97674`、`src-8cb08e01ef59` | 模型只生成参数不执行工具；指定函数/`required`/`AUTO`/`ANY`/`NONE`；强制调用会迫使补全；Pydantic 的邮箱、范围与类型校验。 |
| [LLM JSON 输出与评测闭环](../wiki/pages/llm-json-output-and-evaluation-loop.md) | `src-6ffb7205f02c`、`src-e0d653cccec7`、`src-d98c9cc1c885`、`src-41e6f94ade42`、`src-f41da1ddf6cd` | 提示词 JSON 与受限采样区别；预填 `{` 的旧模型限制；代码/人工/模型 grader；`valid_schema` 与 `accuracy` 分离；失败分析、基线、TPR/TNR。 |
| [LLM 检索增强与知识接地](../wiki/pages/llm-retrieval-augmentation-and-grounding.md) | `src-8e1ca8281233`、`src-7b9e3deae953`、`src-ac9941325f62`、`src-32f1dae15b13` | Search-Ask 与 token 预算；检索/端到端分开评测；Precision/Recall/F1/MRR；上下文嵌入、BM25 混合与重排；Google Search/自定义库 Grounding、引用与隐私提示。 |

审核中补入一条容易误用的版本限制：Anthropic JSON Mode 固定版本写明，预填 `{` 只被旧版 Claude Haiku 4.5 接受，当前模型（包括 Claude Haiku 5.5）会返回 400。该限制已写入已审页，不能只照搬示例代码。

## 实测记录

| 操作 | 实际结果 |
|---|---|
| 首次登记 13 条来源 | 全部 `created`，退出 0 |
| 再次登记同 13 条来源 | 全部 `duplicate`，ID 不变，退出 0 |
| 页面类型修正 | CLI 允许 `concept`/`tool`/`comparison`/`topic`；初稿误用 `guide` 报 3 个 `PAGE` 错误，已分别改为 `topic`、`topic`、`concept` 后重跑通过 |
| `reindex --as-of 2026-11-25` | `indexed 5 page(s); updated 3 file(s)`，退出 0 |
| `lint --as-of 2026-11-25` | `0 error(s), 21 warning(s)`：20 条 `LINK_ONLY`、1 条已确认的 `SUPERSEDED`，退出 0 |
| `search "强制函数调用"` | 命中函数调用模式页，退出 0 |
| `search "评测飞轮"` | 命中 JSON 输出与评测闭环页，退出 0 |
| `search "检索增强"` | 命中检索增强与 JSON 评测相关页，退出 0 |
| `unittest discover -s tests -v` | 7/7 通过，退出 0 |
| 实际计数 | `sources=20 reviewed_pages=5` |

## 当前边界

M3 的 20–30 份真实来源目标已达到下限。下一步是 M4：10 道真实问题、候选召回与答案引用评测、证据不足题、备份恢复；Obsidian 客户端显示仍未实测。固定链接策略仍留下离线复核风险，由用户在下次复核或需要离线使用时决定是否改为经许可核对后的原文快照。
