# 实现检查记录

日期：2026-11-25；Windows；Python 3.13.14、PyYAML 6.0.3、Git 2.55.0.windows.3。依赖检查无冲突；已初始化本地独立仓库，无远程、未提交正式项目内容。忽略规则已用假路径验证原文、收件箱和 `.env` 不会被纳入常规跟踪。

从项目根复跑（使用已装依赖的 Python）：

```text
python -m pip check
python -m unittest discover -s tests -v
python scripts/kb.py reindex --as-of 2026-11-25 --check
python scripts/kb.py lint --as-of 2026-11-25
```

| 项目 | 结果 |
|---|---|
| 合成测试 | 7/7 通过，退出 0。覆盖 CLI 参数、重复登记与原文保留、续版、四域索引、UTF-8 搜索、质检门禁、工作区以外路径、测试仓库回滚。 |
| 空库 | 已生成首页和四域列表；索引复核成功；质检 0 错误、0 警告。空库没有待审或已审正文，不代表资料内容已验收。 |
| 配置 | 本地仓库独立于父目录；`git check-ignore` 对 `raw/blobs/`、`inbox/`、`.env` 生效。 |

基线时未实测：Obsidian 客户端界面、真实资料导入与事实审阅、10 道真实问答、备份恢复。符号链接及 Windows 重解析点拦截已在实现中加入，但本机测试未创建这两类对象。接手执行者先复跑基线，确认第一主题、来源与授权，再做 M3–M4，不要重新搭架构。

## 2026-11-25 接手复跑

环境：Windows；虚拟环境 Python 3.13.14、PyYAML 6.0.3、Git 2.49.0.windows.1。`tech-wiki/` 是独立 Git 仓库，未配置远程；常见安装路径未发现 Obsidian，客户端显示仍未实测。

| 复跑项 | 实际结果 |
|---|---|
| `./.venv/Scripts/python.exe -m pip check` | `No broken requirements found.`，退出 0 |
| `./.venv/Scripts/python.exe scripts/kb.py --help` | 显示 `register`、`reindex`、`search`、`lint`，退出 0 |
| `./.venv/Scripts/python.exe -m unittest discover -s tests -v` | 7/7 通过，退出 0 |
| `./.venv/Scripts/python.exe scripts/kb.py reindex --as-of 2026-11-25 --check` | `index OK`，退出 0 |
| `./.venv/Scripts/python.exe scripts/kb.py lint --as-of 2026-11-25` | `lint: 0 error(s), 0 warning(s)`，退出 0 |
| `git check-ignore -v raw/blobs/fake.md inbox/fake.yml .env` | 三项分别命中 `.gitignore` 第 1、2、8 行，退出 0 |

结论：M0 环境识别与 M2 基线复跑通过；M3 已扩展到 20 条真实来源记录与 5 篇已审页。首批发布见 [m3-pilot.md](m3-pilot.md)，第二批真实续版与审核见 [m3-batch2.md](m3-batch2.md)，第三批扩量见 [m3-batch3.md](m3-batch3.md)。M4 真实问答见 [qa-results.md](qa-results.md)：首轮候选召回 7/8，连续两轮复现 Q8 失败后只补目标页别名，第三轮召回 8/8；答案正确 8/8、关键引用可定位 8/8、证据不足题 2/2。备份恢复见 [backup-restore.md](backup-restore.md)：64/64 文件哈希一致，恢复后索引、质检与 7 项单测通过。当前质检为 0 错误、20 条 `LINK_ONLY` 和 1 条已确认的 `SUPERSEDED` 警告。

## 尚未验证的边界

- Obsidian 客户端显示：本机常见安装路径未发现 Obsidian，未执行界面验收。
- 独立人工盲评：当前 M4 是用户授权 AI 的本地自评，不冒充独立人工审阅。
- Git 历史回滚：仓库尚无提交，备份验证覆盖 `.git` 元数据与工作文件，不覆盖历史提交恢复。
- 离线原文复核：20 条来源均为固定提交链接，`raw/blobs/` 为空，断网恢复原文未验证。
- 符号链接与 Windows 重解析点拦截：代码已实现，本机未创建这两类对象做实测。
