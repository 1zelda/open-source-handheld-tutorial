# M4 备份与恢复验收

日期：2026-11-25  
范围：本地 `tech-wiki/` 规则、CLI、测试、来源目录、Wiki、索引和现有 Git 元数据。未提交、未推送、未上传。

## 备份位置与完整性

- 备份目录：`F:\开源掌机教程\tech-wiki-backup-2026-11-25\`
- 归档：`tech-wiki-backup-2026-11-25\tech-wiki.tar`
- 清单：`tech-wiki-backup-2026-11-25\manifest.json`
- 归档 SHA-256：`880b3c8dfeafbc08a6ea22863f7d2b1b1db1d274c109da33563d1a66cb78c7be`
- 清单 SHA-256：`ae2b09db7fba64a36e9759ae5b1ad0c68981fe87de3ee10b44e7d6e9c1c50fb0`
- 清单覆盖：64 个文件，114,046 字节；排除 `.venv/`、`.cache/` 与 `__pycache__/`，保留 `.git/`。

当前仓库没有任何提交，只有空的 Git 元数据；因此本次验证的是“工作文件与 Git 元数据恢复”，不是“从历史提交回滚”。正式内容仍未提交，符合本轮未获 Git 提交授权的边界。

`raw/blobs/` 为空，20 条来源全部为 `link_only`。本次没有可恢复的本地原文快照；固定提交链接、来源 ID、版本和证据定位随目录恢复，但断网离线复核仍未验证。

## 空目录恢复

1. 新建此前不存在的 `tech-wiki-backup-2026-11-25\restore\`。
2. 将归档解压到该空目录，得到 `restore\tech-wiki\`。
3. 按清单逐文件比较大小与 SHA-256：64/64 一致，0 缺失、0 不匹配。
4. 在恢复副本重建 `.venv`，安装锁定的 `PyYAML==6.0.3`；`pip check` 无冲突。
5. 复跑 CLI、索引、质检和单测。
6. 打开恢复副本的 `wiki/index.md`，核对四域入口和 5 个已审条目；沿 `wiki/pages/llm-function-calling-modes-and-validation.md` 的 `[S1]` 证据链接打开 `raw/catalog/src-cd3e1fd79d89.yml`，来源 ID、固定提交 URL 与版本字段完整。
7. 记录结果后删除临时 `restore\` 目录；保留归档和清单。

## 复跑结果

恢复副本环境：Python 3.13.3、PyYAML 6.0.3。

| 命令 | 实际结果 | 退出码 |
|---|---|---:|
| `./.venv/Scripts/python.exe -m pip check` | `No broken requirements found.` | 0 |
| `./.venv/Scripts/python.exe scripts/kb.py --help` | 显示 `register`、`reindex`、`search`、`lint` | 0 |
| `./.venv/Scripts/python.exe scripts/kb.py reindex --as-of 2026-11-25 --check` | `index OK` | 0 |
| `./.venv/Scripts/python.exe scripts/kb.py lint --as-of 2026-11-25` | `0 error(s), 21 warning(s)`：20 条 `LINK_ONLY`、1 条已确认 `SUPERSEDED` | 0 |
| `./.venv/Scripts/python.exe -m unittest discover -s tests -v` | 7/7 通过 | 0 |
| `git rev-parse --is-inside-work-tree` | `true` | 0 |
| `git status --short` | 与原仓库一致：全部项目文件尚未跟踪（仓库无提交） | 0 |

结论：本地文件备份与空目录恢复通过；Git 历史回滚、离线原文快照和 Obsidian 客户端显示未验证，不能据本次结果宣称已完成这三项。
