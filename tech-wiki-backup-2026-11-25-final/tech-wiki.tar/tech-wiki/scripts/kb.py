"""Local, model-independent Markdown knowledge base CLI."""
import argparse
from datetime import date
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys
import tempfile
import unicodedata
from urllib.parse import parse_qsl, unquote, urlsplit, urlunsplit

import yaml

ROOT = Path(__file__).resolve().parents[1]
DOMAINS = {"ai": "人工智能", "web": "互联网与软件工程", "games": "游戏技术", "security": "网络安全防御"}
KINDS = {"official-doc", "release-note", "paper", "advisory", "article"}
SOURCE_FIELDS = set("schema_version id title origin_key url publisher kind published_on captured_on version access material blob sha256 supersedes".split())
DERIVED = {"schema_version", "id", "material", "blob", "sha256"}
PAGE_FIELDS = set("schema_version id title type domains aliases status updated_on reviewed_on review_due source_ids".split())
SID = re.compile(r"src-[a-f0-9]{12}\Z")
SLUG = re.compile(r"[a-z0-9]+(?:-[a-z0-9]+)*\Z")
RESERVED = re.compile(r"(?:con|prn|aux|nul|(?:com|lpt)[1-9])\Z")
LINK = re.compile(r"(?<!!)\[[^\]\n]+\]\(([^\s)]+)\)")
CITE = re.compile(r"\[(S[1-9][0-9]*)\]")
EVIDENCE = re.compile(r"- \[(S[1-9][0-9]*)\] \[[^\]]+\]\(\.\./\.\./raw/catalog/(src-[a-f0-9]{12})\.yml\) — (\S.*)")


class Problem(ValueError):
    pass


class StrictLoader(yaml.SafeLoader):
    def construct_mapping(self, node, deep=False):
        result = {}
        for key_node, value_node in node.value:
            key = self.construct_object(key_node, deep=deep)
            if not isinstance(key, str) or key in result:
                raise Problem("YAML 键重复或不是字符串")
            result[key] = self.construct_object(value_node, deep=deep)
        return result


def require(ok, message):
    if not ok:
        raise Problem(message)


def dt(value):
    require(isinstance(value, str) and re.fullmatch(r"\d{4}-\d{2}-\d{2}", value), "日期必须是带引号的 YYYY-MM-DD")
    try:
        return date.fromisoformat(value)
    except ValueError as exc:
        raise Problem("无效日期") from exc


def as_of_arg(value):
    try:
        return dt(value)
    except Problem as exc:
        raise argparse.ArgumentTypeError(str(exc)) from exc


def text(value):
    return isinstance(value, str) and bool(value.strip()) and "\n" not in value and "\r" not in value


def load_yaml(raw):
    try:
        obj = yaml.load(raw, Loader=StrictLoader)
    except yaml.YAMLError as exc:
        raise Problem("无效 YAML（原始内容省略）") from exc
    require(isinstance(obj, dict), "YAML 顶层必须为映射")
    return obj


def regular_path(path):
    """Validate path lexically and inspect each component without following links."""
    path = Path(os.path.abspath(path))
    require(path.is_relative_to(ROOT), "路径必须位于项目内")
    cur = ROOT
    for part in path.relative_to(ROOT).parts:
        cur = cur / part
        try:
            info = cur.lstat()
        except FileNotFoundError:
            continue
        attrs = getattr(info, "st_file_attributes", 0)
        require(not stat.S_ISLNK(info.st_mode) and not attrs & 0x400, "不接受符号链接或重解析点")
    return path


def incoming(value):
    path = regular_path(ROOT / value)
    require(path.is_relative_to(ROOT / "inbox") and path.is_file(), "输入必须是 inbox/ 内的现有普通文件")
    return path


def atomic(path, data, *, new=False):
    path = regular_path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=".kb-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
        if new:
            os.link(name, path)
        else:
            os.replace(name, path)
    finally:
        Path(name).unlink(missing_ok=True)


def canonical_url(value):
    require(text(value) and not any(c.isspace() for c in value), "无效 URL")
    parts = urlsplit(value)
    require(parts.scheme.lower() in {"https", "http"} and parts.hostname and parts.username is None and parts.password is None, "URL 须为不含凭证的 HTTP(S)")
    host = parts.hostname.lower()
    if ":" in host:
        host = "[" + host + "]"
    port = parts.port
    if port is not None and (parts.scheme.lower(), port) not in {("https", 443), ("http", 80)}:
        host += f":{port}"
    kept = []
    forbidden = {"token", "access_token", "apikey", "api_key", "password", "secret", "signature", "sig", "auth", "key", "code", "auth_token"}
    for item in parts.query.split("&") if parts.query else []:
        items = parse_qsl(item, keep_blank_values=True)
        key = (items[0][0] if items else "").casefold()
        require(key not in forbidden and not key.startswith(("x-amz-", "x-goog-")), "URL 可能含访问凭证")
        if not (key.startswith("utm_") or key in {"gclid", "fbclid"}):
            kept.append(item)
    return urlunsplit((parts.scheme.lower(), host, parts.path, "&".join(kept), ""))


def source_id(src):
    key = [src[k] for k in ("origin_key", "version", "material", "sha256")]
    raw = json.dumps(key, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return "src-" + hashlib.sha256(raw).hexdigest()[:12]


def source_valid(src, day):
    require(set(src) == SOURCE_FIELDS and type(src["schema_version"]) is int and src["schema_version"] == 1, "来源字段或 schema_version 不符")
    for field in ("title", "origin_key", "publisher"):
        require(text(src[field]), f"来源字段 {field} 不能为空")
    require(src["access"] == "public", "本库只接收授权的公开内容")
    require(src["kind"] in KINDS, "来源类型不符")
    require(src["version"] is None or text(src["version"]), "版本必须为字符串或 null")
    require(dt(src["captured_on"]) <= day, "采集日期晚于检查日")
    if src["published_on"] is not None:
        dt(src["published_on"])
    if src["url"] is not None:
        canonical_url(src["url"])
    if src["origin_key"].lower().startswith(("http://", "https://")):
        require(canonical_url(src["origin_key"]) == src["origin_key"], "origin_key 不是规范 URL")
    else:
        require(re.fullmatch(r"[A-Za-z][A-Za-z0-9+.-]+:[^\s\\]+", src["origin_key"]), "非 URL 来源需稳定标识，如 doi:...")
    require(isinstance(src["id"], str) and bool(SID.fullmatch(src["id"])) and src["id"] == source_id(src), "来源 ID 与身份键不符")
    prev = src["supersedes"]
    require(prev is None or isinstance(prev, str) and bool(SID.fullmatch(prev)), "续版来源 ID 格式错误")
    if src["material"] == "snapshot":
        require(isinstance(src["blob"], str) and re.fullmatch(r"raw/blobs/" + src["id"] + r"\.[a-z0-9]{1,10}", src["blob"]), "快照路径不合法")
        require(isinstance(src["sha256"], str) and re.fullmatch(r"[a-f0-9]{64}", src["sha256"]), "无效快照哈希")
    else:
        require(src["material"] == "link_only" and src["url"] and src["blob"] is None and src["sha256"] is None, "仅链接来源必须无快照字段")


def read_source(path, day):
    record = load_yaml(regular_path(path).read_text(encoding="utf-8"))
    source_valid(record, day)
    require(path.stem == record["id"], "来源 ID 必须与文件名相同")
    if record["material"] == "snapshot":
        blob = regular_path(ROOT / record["blob"])
        require(blob.is_file(), "缺失原文快照")
        with blob.open("rb") as file:
            digest = hashlib.file_digest(file, "sha256").hexdigest()
        require(digest == record["sha256"], "原文 SHA-256 不符")
    return record


def register(args):
    record = load_yaml(incoming(args.meta).read_text(encoding="utf-8"))
    fields = SOURCE_FIELDS - DERIVED
    require(set(record) <= fields and fields - {"origin_key", "supersedes"} <= set(record), "来源输入字段不完整或含保留字段")
    record.setdefault("supersedes", None)
    if record["url"] is not None:
        url_key = canonical_url(record["url"])
        record.setdefault("origin_key", url_key)
    require("origin_key" in record, "无 URL 时须给稳定的 origin_key")
    payload = incoming(args.file).read_bytes() if args.file else None
    record.update(schema_version=1, material="snapshot" if payload is not None else "link_only", sha256=hashlib.sha256(payload).hexdigest() if payload is not None else None)
    record["id"] = sid = source_id(record)
    suffix = Path(args.file).suffix.lower() if args.file else ""
    record["blob"] = f"raw/blobs/{sid}{suffix}" if payload is not None else None
    today = date.today()
    source_valid(record, today)
    target = regular_path(ROOT / "raw/catalog" / f"{sid}.yml")
    if target.exists():
        existing = read_source(target, today)
        require(all(existing[k] == record[k] for k in ("origin_key", "version", "material", "sha256")), "来源短哈希碰撞")
        print(f"duplicate {sid}")
        return 0
    if record["supersedes"]:
        require(record["supersedes"] != sid, "不能指向自身")
        old = read_source(ROOT / "raw/catalog" / f"{record['supersedes']}.yml", today)
        require(old["origin_key"] == record["origin_key"], "续版必须来自同一来源")
    if payload is not None:
        blob = regular_path(ROOT / record["blob"])
        require(not blob.exists(), "快照已存在，先人工核对中断产生的孤立文件")
        atomic(blob, payload, new=True)
    atomic(target, yaml.safe_dump(record, allow_unicode=True, sort_keys=False).encode("utf-8"), new=True)
    print(f"created {sid}")
    return 0


def visible(text_value):
    fence = None
    for number, line in enumerate(text_value.splitlines(), 1):
        match = re.match(r"^\s{0,3}(`{3,}|~{3,})(.*)$", line)
        if match:
            mark, rest = match.groups()
            if fence is None:
                fence = mark
                continue
            if mark[0] == fence[0] and len(mark) >= len(fence) and not rest.strip():
                fence = None
                continue
        if fence is None:
            yield number, line


def parse_page(path, day):
    raw = regular_path(path).read_text(encoding="utf-8")
    parts = re.split(r"^---\n", raw, maxsplit=2, flags=re.M)
    require(len(parts) == 3 and parts[0] == "", "缺少 YAML front matter")
    page = load_yaml(parts[1])
    require(set(page) == PAGE_FIELDS and type(page["schema_version"]) is int and page["schema_version"] == 1, "页面字段或 schema_version 不符")
    require(isinstance(page["id"], str) and page["id"] == path.stem and SLUG.fullmatch(page["id"]) and not RESERVED.fullmatch(page["id"]), "页面 ID 无效或与文件名不符")
    require(text(page["title"]) and page["type"] in {"concept", "tool", "comparison", "topic"}, "标题或类型无效")
    for field in ("domains", "aliases", "source_ids"):
        arr = page[field]
        require(isinstance(arr, list) and all(map(text, arr)) and len(arr) == len(set(arr)), f"{field} 必须是无重复字符串列表")
    require(page["domains"] and all(d in DOMAINS for d in page["domains"]), "领域无效")
    require(all(SID.fullmatch(x) for x in page["source_ids"]), "页面来源 ID 无效")
    require(dt(page["updated_on"]) <= day, "更新日不能晚于检查日")
    if page["status"] == "draft":
        require(page["reviewed_on"] is None and page["review_due"] is None, "草稿不得标已审日期")
    else:
        require(page["status"] in {"reviewed", "stale"}, "页面状态无效")
        require(dt(page["reviewed_on"]) <= day and dt(page["review_due"]) >= dt(page["reviewed_on"]), "审阅日期不合法")
        require(page["source_ids"], "已审或过期页面不能没有来源")
    body = parts[2]
    headings = [line for _, line in visible(body) if line.startswith("# ")]
    require(headings == ["# " + page["title"]], "正文须有一个与 title 相同的一级标题")
    in_evidence = False
    content, cited, defined, evidence_ids = [], set(), set(), set()
    for _, line in visible(body):
        if line.startswith("## "):
            in_evidence = line.strip() == "## 证据"
            if in_evidence:
                continue
        if in_evidence:
            if not line.strip():
                continue
            match = EVIDENCE.fullmatch(line)
            require(match, "证据行必须使用 [S1]、来源相对链接和定位格式")
            label, sid, _ = match.groups()
            require(label not in defined, "证据编号重复")
            defined.add(label)
            evidence_ids.add(sid)
        else:
            cited.update(CITE.findall(line))
            content.append(line)
    require(cited == defined, "证据编号未定义或未引用")
    require(evidence_ids == set(page["source_ids"]), "证据区与 source_ids 不一致")
    page.update(body=body, content="\n".join(content), path=path)
    return page


def old(page, day):
    return page["status"] == "stale" or (page["status"] == "reviewed" and dt(page["review_due"]) <= day)


def link_target(path, target):
    require(not "\\" in target, "链接须用正斜杠")
    parts = urlsplit(target)
    if parts.scheme:
        require(parts.scheme in {"http", "https", "mailto"}, "链接协议不受支持")
        return None
    require(not parts.netloc and not parts.path.startswith("/"), "内部链接必须为相对路径")
    candidate = regular_path(path.parent / unquote(parts.path)) if parts.path else path
    require(candidate.is_file(), f"断链：{target}")
    return candidate


def files(folder, glob):
    return sorted(regular_path(ROOT / folder).glob(glob))


def inspect(day, derived=False):
    sources, pages, errors, warnings = {}, {}, [], []
    def report(group, code, path, msg, line=None):
        group.append(f"{code} {path.relative_to(ROOT).as_posix()}" + (f":{line}" if line else "") + f" {msg}")
    for path in files("raw/catalog", "*.yml"):
        try:
            src = read_source(path, day)
            require(src["id"] not in sources, "重复来源 ID")
            sources[src["id"]] = src
        except (ValueError, TypeError, OSError, yaml.YAMLError) as exc:
            report(errors, "SOURCE", path, str(exc))
    for sid, src in sources.items():
        src_path = ROOT / "raw/catalog" / f"{sid}.yml"
        seen = {sid}
        p = src["supersedes"]
        while p:
            if p in seen or p not in sources or sources[p]["origin_key"] != src["origin_key"]:
                report(errors, "VERSIONS", src_path, "续版引用缺失、跨来源或形成循环")
                break
            seen.add(p)
            p = sources[p]["supersedes"]
        if src["material"] == "link_only":
            report(warnings, "LINK_ONLY", src_path, "仅链接，原文不一定可离线复核")
    for path in files("wiki/pages", "*.md"):
        try:
            page = parse_page(path, day)
            require(page["id"] not in pages, "重复页面 ID")
            require(set(page["source_ids"]) <= sources.keys(), "页面引用的来源不存在")
            pages[page["id"]] = page
            if old(page, day):
                report(warnings, "STALE", path, "条目已到期或已过期")
        except (ValueError, TypeError, OSError, yaml.YAMLError) as exc:
            report(errors, "PAGE", path, str(exc))
    used = {sid for p in pages.values() for sid in p["source_ids"]}
    superseded = {s["supersedes"] for s in sources.values() if s["supersedes"]}
    referenced_blobs = {s["blob"] for s in sources.values() if s["blob"]}
    for path in files("raw/blobs", "*"):
        if path.relative_to(ROOT).as_posix() not in referenced_blobs:
            report(warnings, "ORPHAN_BLOB", path, "未被有效快照记录引用")
    for sid in sorted(sources.keys() - used):
        report(warnings, "UNUSED_SOURCE", ROOT / "raw/catalog" / f"{sid}.yml", "未引用来源")
    linked = set()
    paths = [p["path"] for p in pages.values()]
    navigation = [ROOT / "wiki/index.md", *(ROOT / "wiki/domains" / f"{d}.md" for d in DOMAINS)]
    for path in paths + (navigation if derived else []):
        try:
            data = regular_path(path).read_text(encoding="utf-8")
            if path in paths:
                _, front_matter, data = re.split(r"^---\n", data, maxsplit=2, flags=re.M)
                front_matter_lines = front_matter.count("\n") + 2
            else:
                front_matter_lines = 0
            for line_no, line in visible(data):
                for target in LINK.findall(line):
                    try:
                        to = link_target(path, target)
                        if to in paths and to != path and path in paths:
                            linked.add(to)
                    except (ValueError, OSError) as exc:
                        report(errors, "LINK", path, str(exc), line_no + front_matter_lines)
        except (ValueError, OSError) as exc:
            report(errors, "READ", path, str(exc))
    for page in pages.values():
        if page["status"] == "reviewed" and page["path"] not in linked:
            report(warnings, "ORPHAN_PAGE", page["path"], "未被其他知识页链接")
        if page["status"] != "draft" and superseded.intersection(page["source_ids"]):
            report(warnings, "SUPERSEDED", page["path"], "引用的来源已有续版，需确认是否影响结论")
    return pages, errors, warnings


def norm(text_value):
    return unicodedata.normalize("NFKC", text_value).casefold()


def show_issues(errors, warnings=()):
    for code, items in (("ERROR", errors), ("WARN", warnings)):
        for item in items:
            print(f"{code} {item}", file=sys.stderr)


def reindex(args):
    pages, errors, _ = inspect(args.as_of)
    if errors:
        show_issues(errors)
        return 1
    active = sorted((p for p in pages.values() if p["status"] != "draft"), key=lambda p: (p["domains"][0], norm(p["title"]), p["id"]))
    nav = {ROOT / "wiki/index.md": ["# 技术知识库", "", *[f"- [{title}](domains/{d}.md)" for d, title in DOMAINS.items()], "", "## 条目", ""]}
    for domain, title in DOMAINS.items():
        nav[ROOT / "wiki/domains" / f"{domain}.md"] = [f"# {title}", "", "[返回总索引](../index.md)", ""]
    for path, lines in nav.items():
        subset = active if path.stem == "index" else [p for p in active if path.stem in p["domains"]]
        base = "pages" if path.stem == "index" else "../pages"
        if not subset:
            lines.append("暂无已审条目。")
        for p in subset:
            title = p["title"].replace("[", "（").replace("]", "）")
            status_value = "（待复核）" if old(p, args.as_of) else ""
            lines.append(f"- [{title}]({base}/{p['id']}.md){status_value}")
    differences = []
    for path, lines in nav.items():
        content = ("\n".join(lines) + "\n").encode("utf-8")
        safe = regular_path(path)
        if not safe.is_file() or safe.read_bytes() != content:
            differences.append(safe.relative_to(ROOT).as_posix())
            if not args.check:
                atomic(safe, content)
    if args.check and differences:
        show_issues([f"INDEX_DRIFT {p}" for p in differences])
        return 1
    print("index OK" if args.check else f"indexed {len(active)} page(s); updated {len(differences)} file(s)")
    return 0


def search(args):
    pages, errors, _ = inspect(args.as_of)
    if errors:
        show_issues(errors)
        return 1
    q = norm(args.query.strip())
    terms = set(q.split())
    if not terms:
        raise Problem("查询不能为空")
    results = []
    for p in pages.values():
        if p["status"] == "draft" or (old(p, args.as_of) and not args.include_stale):
            continue
        if args.domain and args.domain not in p["domains"]:
            continue
        title, aliases, content = norm(p["title"]), [norm(a) for a in p["aliases"]], norm(p["content"])
        points = 12 * (title == q) + 10 * (q in aliases)
        matches = []
        for name, weight, scores in [("title", 4, [title]), ("aliases", 3, aliases), ("body", 1, [content])]:
            count = sum(any(t in field for field in scores) for t in terms)
            if count:
                matches.append(name)
                points += count * weight
        if points:
            results.append((points, p["id"], p, ",".join(matches)))
    for points, pid, p, fields in sorted(results, key=lambda item: (-item[0], item[1]))[: args.limit]:
        status_value = "stale" if old(p, args.as_of) else "reviewed"
        print(f"{pid}\t{p['title']}\t{p['path'].relative_to(ROOT).as_posix()}\t{fields}\t{status_value}")
    if not results:
        print("no results")
    return 0


def lint(args):
    _, errors, warnings = inspect(args.as_of, derived=True)
    show_issues(errors, warnings)
    print(f"lint: {len(errors)} error(s), {len(warnings)} warning(s)")
    return int(bool(errors))


def limit_arg(value):
    try:
        n = int(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("limit must be in 1..50") from exc
    if not 1 <= n <= 50:
        raise argparse.ArgumentTypeError("limit must be in 1..50")
    return n


def main(argv=None):
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    r = commands.add_parser("register")
    r.add_argument("--meta", required=True)
    r.add_argument("--file")
    i = commands.add_parser("reindex")
    i.add_argument("--as-of", type=as_of_arg, required=True)
    i.add_argument("--check", action="store_true")
    s = commands.add_parser("search")
    s.add_argument("query")
    s.add_argument("--as-of", type=as_of_arg, default=date.today())
    s.add_argument("--domain", choices=DOMAINS)
    s.add_argument("--limit", type=limit_arg, default=10)
    s.add_argument("--include-stale", action="store_true")
    l = commands.add_parser("lint")
    l.add_argument("--as-of", type=as_of_arg, required=True)
    args = parser.parse_args(argv)
    if args.command == "search" and not args.query.strip():
        parser.error("search query cannot be empty")
    try:
        return {"register": register, "reindex": reindex, "search": search, "lint": lint}[args.command](args)
    except (ValueError, TypeError, OSError, yaml.YAMLError) as exc:
        # Default YAML exceptions can include the input line; don't echo it.
        message = "无效 YAML（原始内容省略）" if isinstance(exc, yaml.YAMLError) else str(exc)
        print(f"ERROR {args.command.upper()} {message}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
