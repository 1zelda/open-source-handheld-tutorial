---
schema_version: 1
id: llm-function-calling-modes-and-validation
title: LLM 函数调用模式与参数校验
type: topic
domains: [ai, web]
aliases: [Function Calling, Tool Choice, Required Tool, Pydantic Validation, 工具调用, 参数校验, 强制函数调用]
status: reviewed
updated_on: '2026-11-25'
reviewed_on: '2026-11-25'
review_due: '2027-02-23'
source_ids: [src-cd3e1fd79d89, src-7667917a0683, src-a403dde97674, src-8cb08e01ef59]
---
# LLM 函数调用模式与参数校验

## 核心流程

- 模型只负责根据工具声明返回函数名和参数，外部函数仍由应用执行；返回结果后需要再次进入对话，才能让模型基于工具结果作答。[S1]
- OpenAI 示例把调用闭环分成四步：模型选择工具、程序检查调用、提取参数并执行、把结果追加到消息后再次请求模型。[S1]
- Gemini 的 `AUTO`、`ANY`、`NONE` 分别表示由模型自行决定、强制从允许集合中调用、禁用函数调用；`ANY` 可用 `allowed_function_names` 限定候选函数。[S4]
- OpenAI 的 `tool_choice='required'` 可让每次请求都产生工具调用，适合受控流程；指定具体函数和 `none` 则用于更窄的控制。[S1][S2]

## 参数校验

- 工具 schema 约束的是输入形状，不等于业务规则已经满足。Anthropic 示例用 Pydantic 定义 `Note`、`Author` 与响应模型，并显式限制 `priority` 在 1–5、邮箱格式与布尔字段。[S3]
- 生产执行前至少应检查工具名是否在白名单、参数能否解析、类型和范围是否合法、用户是否有权限、操作是否幂等，以及失败如何回传。[S1][S3]
- 强制调用可能迫使模型在信息不足时补全参数。OpenAI 教程明确展示：强制指定预测函数后，模型会为缺失字段作假设；这类结果不能绕过校验。[S1]
- `required` 或 `ANY` 提供的是控制流确定性，不是答案正确性或业务安全性保证。[S2][S4]

## 选择建议

- 需要模型自行判断是否调用：使用默认/`AUTO`。
- 业务流程必须经过某个工具：使用指定函数、`required` 或 `ANY`，并缩小工具集合。
- 禁止外部调用：使用 `none`/`NONE`，但模型仍可能仅凭训练数据回答。
- 对写操作、支付、数据库修改等副作用：在 schema 之外增加权限、确认、审计和幂等控制。

## 版本与边界

这些教程固定在不同供应商与 SDK 版本中，参数名和模型支持范围会变化。迁移时应重查当前官方文档，并用最小样本验证“是否调用、调用哪个、参数是否合法、结果是否回传”，不能只替换模型字符串。[S1][S4]

## 相关条目

- [LLM 结构化输出与工具调用](llm-structured-outputs-and-tool-calling.md)
- [LLM 工具调用的并行、多智能体与版本迁移](llm-tool-calling-parallel-and-versioning.md)
- [LLM JSON 输出与评测闭环](llm-json-output-and-evaluation-loop.md)
- [LLM 检索增强与知识接地](llm-retrieval-augmentation-and-grounding.md)

## 证据

- [S1] [How to call functions with chat models](../../raw/catalog/src-cd3e1fd79d89.yml) — 开篇工具执行边界、“Forcing the use of specific functions or no function” `cell-17`–`cell-22`、并行调用 `cell-23`–`cell-24`、四步调用说明 `cell-35`；版本 20793784ac467f06ed67f3e3e9349dc9596894e0。
- [S2] [Using Tool Required for Customer Service](../../raw/catalog/src-7667917a0683.yml) — 开篇 `required` 说明、配置与主循环 `cell-3`–`cell-4`、结论 `cell-14`；版本 20793784ac467f06ed67f3e3e9349dc9596894e0。
- [S3] [Note-Saving Tool with Pydantic and Anthropic Tool Use](../../raw/catalog/src-a403dde97674.yml) — Pydantic 模型 `cell-5`、客户端工具 `cell-7`、工具处理与交互 `cell-10`–`cell-13`、结论 `cell-16`；版本 c43f56d0360b9b1f631bd090fd199231d4c880cc。
- [S4] [Forced Function Calling with Tool Configurations in Gemini](../../raw/catalog/src-8cb08e01ef59.yml) — “Overview” `cell-3`、模式说明 `cell-21`、`AUTO`/`ANY`/`NONE` 示例 `cell-22`–`cell-43`；版本 1f2b36b0cb7500938a119851945d3479cdedc8e8。
