---
schema_version: 1
id: llm-retrieval-augmentation-and-grounding
title: LLM 检索增强与知识接地
type: concept
domains: [ai, web]
aliases: [RAG, Retrieval Augmented Generation, Grounding, Contextual Retrieval, Embedding Search, 检索增强, 知识接地, 上下文检索]
status: reviewed
updated_on: '2026-11-25'
reviewed_on: '2026-11-25'
review_due: '2027-02-23'
source_ids: [src-8e1ca8281233, src-7b9e3deae953, src-ac9941325f62, src-32f1dae15b13]
---
# LLM 检索增强与知识接地

## 基本路线

- 嵌入检索可概括为“Search → Ask”：先把文档分块并嵌入，查询时按向量相似度取回文本，再把检索结果放入提示词让模型作答。[S1]
- OpenAI 示例用余弦相关度排序，并按 token 预算装入上下文；它同时建议打印实际喂给模型的文本，以区分“检索没找到”与“模型推理失败”。[S1]
- Anthropic 基础 RAG 按标题分块、嵌入后用余弦相似度检索；更高级方案依次加入摘要索引、上下文检索、混合检索和重排。[S2][S3]
- Gemini Grounding 可用 `GoogleSearch` 检索公开网页，或用 `VertexAISearch` 检索自定义文档库；响应中的 grounding metadata 可提供支持片段与引用。[S4]

## 检索质量单独评测

- Anthropic RAG 指南要求把检索系统与端到端系统分开评测，不能只看最终答案就判断检索质量。[S2]
- 该教程使用 Precision、Recall、F1、MRR 与端到端准确率：Precision 看取回内容有多少相关，Recall 看相关文档找回多少，MRR 看首个相关结果排在第几位。[S2]
- 改进前先建立同一语料、同一问题集上的基线，再比较 top-k 命中、排序和最终答案。上下文检索教程中的 81%/87%/90% 与后续提升只对应其示例语料，不能当成通用承诺。[S3]

## 上下文与重排

- 独立分块可能缺少文档背景。上下文检索在嵌入前为每个块生成简短“情境说明”，把块放回整篇文档的语境中，再与原块一起嵌入。[S3]
- 混合检索把语义检索与 BM25 等关键词检索融合，降低只用一种表示造成的漏检；重排则在较大候选集上再做相关性排序。[S3]
- 这些步骤增加成本与延迟。是否采用应由固定评测集决定，而不是因为技术在演示中提升就默认上线。[S2][S3]

## 边界与安全

- 检索到文档不等于模型正确使用文档；引用存在也不等于结论被证据支持。应保留来源片段、允许答案拒答，并对关键事实回查。[S1][S4]
- 公开网络 Grounding 会引入外部内容，存在提示注入、隐私和可用性风险；Google 教程也提示公开搜索可能记录客户查询，并给出企业搜索选项。[S4]
- 自建知识库需要处理访问控制、文档新鲜度、分块策略与删除同步。模型不应检索或泄露用户无权访问的内容。[S2][S4]
- 对需要组合多个局部来源的问题，检索增强通常比简单事实查询更难；应分别评测检索和推理，避免盲目归因。[S1]

## 相关条目

- [LLM 结构化输出与工具调用](llm-structured-outputs-and-tool-calling.md)
- [LLM 函数调用模式与参数校验](llm-function-calling-modes-and-validation.md)
- [LLM JSON 输出与评测闭环](llm-json-output-and-evaluation-loop.md)

## 证据

- [S1] [Question answering using embeddings-based search](../../raw/catalog/src-8e1ca8281233.yml) — 开篇“Search-Ask”、“Why search is better than fine-tuning”、检索函数、`ask` 与 token 预算、错误排查和“More examples”；版本 20793784ac467f06ed67f3e3e9349dc9596894e0。
- [S2] [Retrieval Augmented Generation](../../raw/catalog/src-7b9e3deae953.yml) — “Level 1 - Basic RAG”“Eval Setup”“Metric Definitions”、摘要索引与重排章节；版本 c43f56d0360b9b1f631bd090fd199231d4c880cc。
- [S3] [Enhancing RAG with Contextual Retrieval](../../raw/catalog/src-ac9941325f62.yml) — “Basic RAG”基线、“Contextual Embeddings”“Contextual BM25: Hybrid Search”“Reranking”与示例结果边界；版本 c43f56d0360b9b1f631bd090fd199231d4c880cc。
- [S4] [Intro to Grounding with Gemini](../../raw/catalog/src-32f1dae15b13.yml) — “Overview”、Google Search 示例、Enterprise Web Search 隐私提示、自定义文档与聊天接地示例；版本 1f2b36b0cb7500938a119851945d3479cdedc8e8。
