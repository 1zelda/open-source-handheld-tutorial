---
schema_version: 1
id: llm-json-output-and-evaluation-loop
title: LLM JSON 输出与评测闭环
type: topic
domains: [ai, web]
aliases: [JSON Mode, Structured Outputs Evaluation, OpenAI Evals, Grader, JSON 校验, 模型评测, 评测飞轮]
status: reviewed
updated_on: '2026-11-25'
reviewed_on: '2026-11-25'
review_due: '2027-02-23'
source_ids: [src-6ffb7205f02c, src-e0d653cccec7, src-d98c9cc1c885, src-41e6f94ade42, src-f41da1ddf6cd]
---
# LLM JSON 输出与评测闭环

## JSON 输出的两条路线

- 纯提示词“JSON 模式”通过指令、预填 `{`、停止序列或 XML 标签提高可解析性；Anthropic 教程同时提醒，这类方法不是受限采样，不保证严格匹配 schema。[S1]
- 该固定版本明确标注：预填 `{` 只被旧版 Claude Haiku 4.5 接受，当前模型（包括 Claude Haiku 5.5）会返回 400；迁移时不能照搬该技巧。[S1]
- 若需要严格 schema，应使用供应商提供的结构化输出能力。Anthropic 该版本教程指出，当前模型可通过 `output_config.format` 约束输出；提示词技巧仍适合自由推理与文本处理场景。[S1]
- 解析 JSON 后仍要验证字段类型、必填项、取值范围和业务语义。格式合法只是第一道门。

## 评测对象与判分器

- OpenAI Evals 把评测视为“给定输入、生成输出、与理想答案比较”的任务，并强调评测集应覆盖代码和模型升级带来的回归。[S2]
- Anthropic 教程用 golden answer 配合精确匹配代码判分，也展示由模型按 rubric 评分；模型判分器必须在真实样本上试用并人工抽查，不能默认可靠。[S3]
- Google 结构化输出评测把 `valid_schema` 与 `accuracy` 分开：前者检查 JSON Schema，后者用 `deepdiff` 比较抽取内容与参考答案；`exact_match` 对 JSON 格式差异过于敏感。[S4]
- 因此，结构化输出至少应分别报告“可解析率/ schema 通过率”和“业务内容准确率”，避免用一个总分掩盖失败类型。[S3][S4]

## 评测飞轮

1. **分析失败**：人工阅读失败样本，给错误贴标签并归类；自动指标只能说明哪里变了，不能解释为什么失败。[S5]
2. **建立基线**：把失败类型变成测试集和 grader，先量化再改提示词或系统组件。[S5]
3. **定向改进**：每次修改后重跑同一组样本，观察目标错误率和回归。[S5]
4. **持续复查**：新模型、新提示词、新工具和新边界输入都可能产生更隐蔽的失败，评测需要反复执行。[S2][S5]

## 判分器边界

- 类别不平衡时，单一 accuracy 可能误导；OpenAI 建议同时观察 TPR 与 TNR，并划分训练、验证和测试用途，避免把测试集用于调 grader。[S5]
- schema 通过不代表内容正确；内容准确也不代表格式稳定。两类指标应分别断言、分别定位失败。[S4]
- LLM-as-a-judge 适合开放问题，但需要 rubric、校准样本和人工复核；能精确判定的任务优先用代码判分。[S3]

## 相关条目

- [LLM 结构化输出与工具调用](llm-structured-outputs-and-tool-calling.md)
- [LLM 函数调用模式与参数校验](llm-function-calling-modes-and-validation.md)
- [LLM 检索增强与知识接地](llm-retrieval-augmentation-and-grounding.md)

## 证据

- [S1] [Prompting Claude for JSON Mode](../../raw/catalog/src-6ffb7205f02c.yml) — 开篇“without constrained sampling”与结构化输出提示、预填 `{`、停止序列和 XML 标签示例、末尾技巧清单；版本 c43f56d0360b9b1f631bd090fd199231d4c880cc。
- [S2] [Getting Started with OpenAI Evals](../../raw/catalog/src-e0d653cccec7.yml) — “What are evaluations/evals?”、构建与运行评测、失败样本复核；版本 20793784ac467f06ed67f3e3e9349dc9596894e0。
- [S3] [Building Evals](../../raw/catalog/src-d98c9cc1c885.yml) — 输入/输出/golden answer、精确匹配 grader、人工评分与 Claude grader、模型判分器试用提醒；版本 c43f56d0360b9b1f631bd090fd199231d4c880cc。
- [S4] [Evaluate Gemini Structured Output](../../raw/catalog/src-41e6f94ade42.yml) — “Define the prompt and schema”“Define custom metrics for JSON schema validation and accuracy”、`exact_match` 局限与结果分析；版本 1f2b36b0cb7500938a119851945d3479cdedc8e8。
- [S5] [Building resilient prompts using an evaluation flywheel](../../raw/catalog/src-f41da1ddf6cd.yml) — “The evaluation flywheel”“Open Coding”“Adding robustness with automatic graders”、grader 校准与不平衡测试集说明；版本 20793784ac467f06ed67f3e3e9349dc9596894e0。
