---
schema_version: 1
id: llm-structured-outputs-and-tool-calling
title: LLM 结构化输出与工具调用
type: comparison
domains: [ai, web]
aliases: [Structured Outputs, Function Calling, Tool Use, 工具调用, 结构化输出]
status: reviewed
updated_on: '2026-11-25'
reviewed_on: '2026-11-25'
review_due: '2027-02-23'
source_ids: [src-069d3262ba38, src-543ebe01b0b6, src-c7639abd53a1]
---
# LLM 结构化输出与工具调用

## 要点

- OpenAI 的 Structured Outputs 用调用方提供的 JSON Schema 约束响应；`strict: true` 可用于响应格式或函数定义，从而约束 JSON 的形状，而不只是保证它是合法 JSON。[S1]
- Anthropic 的 `tool_choice` 提供 `auto`、`tool`、`any` 三档：`auto` 让模型决定是否调用工具，`tool` 强制调用指定工具，`any` 强制调用已提供工具中的任意一个。[S2]
- Gemini Function Calling 让模型根据函数声明返回函数名和参数；应用负责执行外部系统或数据库调用，并把结果回传给模型。[S3]

## 选型与边界

- 若目标是稳定 JSON 结构，优先考虑供应商提供的结构化输出或函数调用机制，而不是只提示模型“返回 JSON”。[S1][S3]
- 若需要模型自行决定是否调用工具，`auto` 更合适；若业务必须调用某个工具或任一工具，再考虑强制模式。[S2]
- “模型返回函数调用”不等于“模型已经执行工具”。Google 示例明确区分模型生成调用、客户端执行、回传结果三个阶段。[S3]
- 强制工具调用不保证只调用一个工具：Anthropic 教程指出，强制指定工具后仍可能并行调用其他工具；如必须恰好一次，需要使用其提供的并行禁用选项。[S2]
- 处理用户输入时，安全拒绝可能不遵循调用方提供的 schema；OpenAI 为此提供 `refusal` 字段，应用应把拒绝与正常结构化结果分开处理。[S1]

## 版本与限制

- OpenAI 固定提交的结论列出 `gpt-4o-mini`、`gpt-4o-2024-08-06` 和未来模型；这只是该版本当时的能力说明，不代表当前完整模型列表。[S1]
- Anthropic 固定提交的模型说明指出，`claude-haiku-5-5` 接受强制 `tool_choice`，而 Claude Opus 5.5、Sonnet 5.5、Fable 5.1 会返回 400；更换模型前必须重查文档并验证实际 API 行为。[S2]
- Gemini 教程使用 Vertex AI 与 Gen AI SDK，其中自动函数调用示例会触发真实外部 API；复现实验前应确认费用、凭证和调用范围。[S3]

## 相关条目

- [LLM 工具调用的并行、多智能体与版本迁移](llm-tool-calling-parallel-and-versioning.md)

## 证据

- [S1] [Introduction to Structured Outputs](../../raw/catalog/src-069d3262ba38.yml) — “Response format usage”“Function call usage”“Refusal”“Conclusion”；版本 20793784ac467f06ed67f3e3e9349dc9596894e0。
- [S2] [Tool choice](../../raw/catalog/src-543ebe01b0b6.yml) — 开篇三档说明、“Model note”“Auto”“Forcing a specific tool”“Any”；版本 c43f56d0360b9b1f631bd090fd199231d4c880cc。
- [S3] [Intro to Function Calling with the Gemini API & Python SDK](../../raw/catalog/src-c7639abd53a1.yml) — “Overview / Calling functions from Gemini”、聊天示例、地址示例与“Conclusions”；版本 d86c5cbb6d2401960509e1a15827afb1bb9a438a。
