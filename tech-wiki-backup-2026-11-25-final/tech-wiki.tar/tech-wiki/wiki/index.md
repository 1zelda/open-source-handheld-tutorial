# 技术知识库

- [人工智能](domains/ai.md)
- [互联网与软件工程](domains/web.md)
- [游戏技术](domains/games.md)
- [网络安全防御](domains/security.md)

## 条目

- [LLM JSON 输出与评测闭环](pages/llm-json-output-and-evaluation-loop.md)
- [LLM 函数调用模式与参数校验](pages/llm-function-calling-modes-and-validation.md)
- [LLM 工具调用的并行、多智能体与版本迁移](pages/llm-tool-calling-parallel-and-versioning.md)
- [LLM 检索增强与知识接地](pages/llm-retrieval-augmentation-and-grounding.md)
- [LLM 结构化输出与工具调用](pages/llm-structured-outputs-and-tool-calling.md)
