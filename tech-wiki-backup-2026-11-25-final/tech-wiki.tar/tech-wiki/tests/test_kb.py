import hashlib
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

import yaml

SCRIPT = Path(__file__).resolve().parents[1] / "scripts/kb.py"
DAY = "2026-11-25"


class KnowledgeBaseTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        for folder in ("scripts", "inbox", "wiki/pages", "wiki/domains", "raw/catalog", "raw/blobs"):
            (self.root / folder).mkdir(parents=True, exist_ok=True)
        self.script = self.root / "scripts/kb.py"
        shutil.copyfile(SCRIPT, self.script)

    def run_cli(self, *args, code=0):
        result = subprocess.run([sys.executable, str(self.script), *args], cwd=self.root, capture_output=True, text=True, encoding="utf-8", check=False)
        self.assertEqual(result.returncode, code, (args, result.stdout, result.stderr))
        return result

    def put(self, path, text):
        p = self.root / path
        p.write_text(text, encoding="utf-8", newline="\n")
        return p

    def seed(self, *, version="1.x", body="合成快照 1.x", prev=None, snapshot=True):
        record = dict(title="合成来源", url="https://Example.INVALID:443/demo?utm_source=x&lang=zh#intro", publisher="演示发布者", kind="official-doc", published_on=None, captured_on="2025-01-01", version=version, access="public", supersedes=prev)
        self.put("inbox/meta.yml", yaml.safe_dump(record, allow_unicode=True))
        args = ["register", "--meta", "inbox/meta.yml"]
        if snapshot:
            self.put("inbox/demo.md", body)
            args += ["--file", "inbox/demo.md"]
        action, sid = self.run_cli(*args).stdout.strip().split()
        return action, sid

    def page(self, sid, *, pid="prediction", title="客户端预测", status="reviewed", due="2026-12-01", extra=""):
        data = dict(schema_version=1, id=pid, title=title, type="concept", domains=["games", "web"], aliases=["Client-side prediction"], status=status, updated_on="2026-11-01", reviewed_on="2026-11-01" if status != "draft" else None, review_due=due if status != "draft" else None, source_ids=[sid])
        body = f"# {title}\n\n合成规则只演示 1.x。[S1]\n\n{extra}\n\n## 证据\n- [S1] [演示来源](../../raw/catalog/{sid}.yml) — 1.x / 示例一节。\n"
        return self.put(f"wiki/pages/{pid}.md", "---\n" + yaml.safe_dump(data, allow_unicode=True) + "---\n" + body)

    def reindex(self, *flags, code=0):
        return self.run_cli("reindex", "--as-of", DAY, *flags, code=code)

    def lint(self, code=0):
        return self.run_cli("lint", "--as-of", DAY, code=code)

    def test_help_and_arguments(self):
        output = self.run_cli("--help").stdout
        for command in ("register", "reindex", "search", "lint"):
            self.assertIn(command, output)
        self.run_cli("reindex", "--as-of", "2026-02-30", code=2)
        self.run_cli("search", "anything", "--limit", "0", code=2)
        self.run_cli("search", "  ", code=2)

    def test_duplicate_release_and_link(self):
        action, sid = self.seed()
        self.assertEqual(action, "created")
        old_path = self.root / f"raw/blobs/{sid}.md"
        before = hashlib.sha256(old_path.read_bytes()).hexdigest()
        self.assertEqual(self.seed(), ("duplicate", sid))
        _, new = self.seed(version="2.x", body="更新内容", prev=sid)
        self.assertNotEqual(new, sid)
        self.assertEqual(hashlib.sha256(old_path.read_bytes()).hexdigest(), before)
        self.assertEqual(yaml.safe_load((self.root / f"raw/catalog/{new}.yml").read_text(encoding="utf-8"))["supersedes"], sid)
        _, link = self.seed(version=None, snapshot=False)
        self.assertEqual(self.seed(version=None, snapshot=False), ("duplicate", link))
        self.assertEqual(len(list((self.root / "raw/blobs").iterdir())), 2)

    def test_deterministic_navigation(self):
        self.reindex()
        self.assertIn("暂无已审条目", (self.root / "wiki/index.md").read_text(encoding="utf-8"))
        _, sid = self.seed()
        self.page(sid)
        self.page(sid, pid="expired", title="到期条目", due=DAY)
        self.page(sid, pid="draft", title="草稿", status="draft")
        self.reindex()
        paths = list((self.root / "wiki").glob("**/*.md"))
        before = {p: p.read_bytes() for p in paths}
        self.reindex()
        self.assertEqual(before, {p: p.read_bytes() for p in paths})
        self.reindex("--check")
        for domain in ("games", "web"):
            nav = (self.root / f"wiki/domains/{domain}.md").read_text(encoding="utf-8")
            self.assertIn("prediction.md", nav)
            self.assertIn("待复核", nav)
            self.assertNotIn("草稿", nav)
        drifted = self.put("wiki/index.md", "# 人为变更\n")
        self.assertIn("INDEX_DRIFT", self.reindex("--check", code=1).stderr)
        self.assertEqual(drifted.read_text(encoding="utf-8"), "# 人为变更\n")
        self.reindex()
        self.reindex("--check")

    def test_utf8_search_and_filters(self):
        _, sid = self.seed()
        self.page(sid)
        self.page(sid, pid="expired", title="到期条目", due=DAY)
        self.page(sid, pid="secret-draft", title="草稿", status="draft")
        for term in ("客户端预测", "Ｃｌｉｅｎｔ-side prediction", "1.x"):
            out = self.run_cli("search", term, "--as-of", DAY).stdout
            self.assertIn("prediction\t客户端预测", out)
            self.assertNotIn("expired", out)
        self.assertIn("expired", self.run_cli("search", "1.x", "--include-stale", "--as-of", DAY).stdout)
        self.assertEqual(self.run_cli("search", "1.x", "--domain", "ai", "--as-of", DAY).stdout.strip(), "no results")
        self.assertEqual(self.run_cli("search", "草稿", "--include-stale", "--as-of", DAY).stdout.strip(), "no results")

    def test_lint_errors_and_nondestructive_warnings(self):
        _, sid = self.seed()
        p = self.page(sid, extra="```md\n[忽略](unwritten.md)\n```")
        self.reindex()
        self.assertIn("ORPHAN_PAGE", self.lint().stderr)
        self.assertNotIn("unwritten", self.lint().stderr)
        original = p.read_text(encoding="utf-8")
        self.put("wiki/pages/prediction.md", original + "\n## 其他\n[坏链接](missing.md)\n")
        self.assertIn("断链", self.lint(code=1).stderr)
        self.put("wiki/pages/prediction.md", original.replace("规则只演示 1.x。[S1]", "规则只演示 1.x。[S2]"))
        self.assertIn("证据编号", self.lint(code=1).stderr)
        self.put("wiki/pages/prediction.md", original.replace(sid, "src-bbbbbbbbbbbb"))
        self.assertIn("来源不存在", self.lint(code=1).stderr)
        self.put("wiki/pages/prediction.md", original)
        self.put(f"raw/blobs/{sid}.md", "不应修改")
        self.assertIn("SHA-256", self.lint(code=1).stderr)
        self.put("inbox/bad.yml", "title: a\ntitle: b\n")
        self.assertIn("YAML 键重复", self.run_cli("register", "--meta", "inbox/bad.yml", code=1).stderr)

    def test_cycle_and_external_input_rejected(self):
        _, a = self.seed()
        _, b = self.seed(version="2.x", prev=a)
        self.reindex()
        p = self.root / f"raw/catalog/{a}.yml"
        data = yaml.safe_load(p.read_text(encoding="utf-8"))
        data["supersedes"] = b
        p.write_text(yaml.safe_dump(data, allow_unicode=True), encoding="utf-8")
        self.assertIn("VERSIONS", self.lint(code=1).stderr)
        self.run_cli("register", "--meta", "../outside.yml", code=1)

    @unittest.skipUnless(shutil.which("git"), "Git not installed")
    def test_git_revert_preserves_original(self):
        def git(*args):
            r = subprocess.run(["git", *args], cwd=self.root, capture_output=True, check=False)
            self.assertEqual(r.returncode, 0, r.stderr)
            return r.stdout
        git("init", "--quiet")
        git("config", "user.name", "Synthetic Test")
        git("config", "user.email", "synthetic@example.invalid")
        self.put(".gitignore", "/raw/blobs/\n/inbox/\n")
        self.put(".gitattributes", "*.md text eol=lf\n")
        _, sid = self.seed()
        p = self.page(sid)
        raw = (self.root / f"raw/blobs/{sid}.md").read_bytes()
        original = p.read_bytes()
        git("add", "--", ".gitignore", "raw/catalog", "wiki/pages")
        git("commit", "--quiet", "-m", "initial")
        p.write_bytes(original.replace("1.x。[S1]".encode(), "1.x！[S1]".encode()))
        git("add", "--", "wiki/pages/prediction.md")
        self.assertIn("1.x！".encode(), git("diff", "--cached"))
        git("commit", "--quiet", "-m", "update")
        git("revert", "--no-edit", "HEAD")
        self.assertEqual(p.read_bytes(), original)
        self.assertEqual((self.root / f"raw/blobs/{sid}.md").read_bytes(), raw)


if __name__ == "__main__":
    unittest.main()
